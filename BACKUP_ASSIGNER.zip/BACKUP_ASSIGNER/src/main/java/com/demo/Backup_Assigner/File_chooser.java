package com.demo.Backup_Assigner;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JTextField;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.SystemColor;

public class File_chooser {

	private static JFrame frame;
	private static JTextField FilePathname;
	private static JTextField status;
	private static JLabel lblNewLabel_1;

	static ArrayList<String> collobrate_tickets = new ArrayList<String>();

	static ArrayList<String> collobrate_scriptname = new ArrayList<String>();

	static ArrayList<String> collobrate_errorcode = new ArrayList<String>();

	static ArrayList<String> ori_scriptname = new ArrayList<String>();

	static ArrayList<String> collobrate_FI = new ArrayList<String>();

	static ArrayList<String> ori_FI_id = new ArrayList<String>();

	static ArrayList<String> ori_error_code = new ArrayList<String>();

	static ArrayList<String> ori_tickets = new ArrayList<String>();

	static ArrayList<String> created_status = new ArrayList<String>();

	static ArrayList<String> calc_priority = new ArrayList<String>();

	static ArrayList<String> Created_priority = new ArrayList<String>();

	static ArrayList<String> headings = new ArrayList<String>();

	static ArrayList<Integer> counter = new ArrayList<Integer>();

	static String filenames="";

	static int priority = 0;

	static int greater_task = 0;

	static int tasks = 0;

	static int other_cnt = 0;

	private static JTextField ticketsField;
	private static JLabel lblNewLabel_2;
	private static JLabel lblNewLabel_3;
	private static JLabel lblNewLabel_4;
	private static JTextField taskstextField;
	private static JSeparator separator_2;
	private static JTextField more_than_one;
	private static JLabel lblNewLabel_5;
	private static JTextField others;
	private static JLabel lblNewLabel_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					File_chooser window = new File_chooser();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void begin(String text) throws Exception {
		String filename;
		if (!StringUtils.containsIgnoreCase(text, ".xlsx")) {
			filename = text + ".xlsx".trim();
		} else {
			filename = text.toString().trim();
		}

		InputStream input = new FileInputStream(filename);
		int ctr = 1;
		int j = 0;
		Workbook wb = WorkbookFactory.create(input);
		Sheet sheet = wb.getSheetAt(0);

		for (int i = 0; i < 20; i++) {
			ctr = 1;
			Row row = null;
			Cell cell = null;
			boolean isNull = false;
			while (true) {
				try {
					row = sheet.getRow(ctr++);
					cell = row.getCell(j);
					if (j == 2) {
						if (!StringUtils.isBlank(cell.toString())
								&& StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							String cutter = StringUtils.substringBefore(cell.toString(), ".0");
							collobrate_scriptname.add(cutter.trim());
						} else if (!StringUtils.isBlank(cell.toString())
								&& !StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							collobrate_scriptname.add(cell.toString().trim());
						}
					} else if (j == 7) {
						if (!StringUtils.isBlank(cell.toString())
								&& StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							String cutter = StringUtils.substringBefore(cell.toString(), ".0");
							collobrate_FI.add(cutter.trim());
						} else if (!StringUtils.isBlank(cell.toString())
								&& !StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							collobrate_FI.add(cell.toString().trim());
						}
					}

					else if (j == 6) {
						if (!StringUtils.isBlank(cell.toString())
								&& StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							String cutter = StringUtils.substringBefore(cell.toString(), ".0");
							collobrate_errorcode.add(cutter.trim());
						} else if (!StringUtils.isBlank(cell.toString())
								&& !StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							collobrate_errorcode.add(cell.toString().trim());
						}
					}

					else if (j == 17) {
						if (!StringUtils.isBlank(cell.toString())
								&& StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							String cutter = StringUtils.substringBefore(cell.toString(), ".0");
							collobrate_tickets.add(cutter.trim());
						} else if (!StringUtils.isBlank(cell.toString())
								&& !StringUtils.containsIgnoreCase(cell.toString(), ".0")) {
							collobrate_tickets.add(cell.toString().trim());
						}
					}
				} catch (Exception e) {
					isNull = true;
				}
				if (isNull) {
					input.close();
					j++;
					break;
				}

			}
		}
		for (String names : collobrate_tickets) {
			System.out.println(names);
		}
		for (String names : collobrate_scriptname) {
			System.out.println(names);
		}
		for (String names : collobrate_errorcode) {
			System.out.println(names);
		}

		seperator(collobrate_tickets, collobrate_scriptname, collobrate_FI, collobrate_errorcode);

	}

	private void seperator(ArrayList<String> collobrate_tickets2, ArrayList<String> collobrate_scriptname2,
			ArrayList<String> colloborate_Fi, ArrayList<String> collobrate_errorcode2) throws Exception {

		for (String string : collobrate_tickets2) {
			StringTokenizer tokens = new StringTokenizer(string, ":");
			int tokenlength = tokens.countTokens();
			while (tokens.hasMoreTokens()) {
				ori_tickets.add(tokens.nextToken());

			}
			counter.add(tokenlength);
		}
		System.out.println("-----------------------");
		for (Integer value : counter) {
			System.out.println(value);
		}
		System.out.println("-----------------------");

		for (int j = 0; j < counter.size(); j++) {
			priority++;
			tasks++;

			for (int i = 0; i < counter.get(j); i++) {
				if (counter.get(j) <= 1) {
					for (int k = 0; k < counter.get(j); k++) {
						ori_scriptname.add(collobrate_scriptname2.get(j));
						ori_error_code.add(collobrate_errorcode2.get(j));
						created_status.add("Ticket Created");
						Created_priority.add(String.valueOf(priority));
						break;
					}
				} else if (counter.get(j) > 1) {

					for (int k = 0; k < counter.get(j); k++) {
						int center = counter.get(j) / 2;
						if (k == 0) {
							ori_scriptname.add(collobrate_scriptname2.get(j));
							ori_error_code.add(collobrate_errorcode2.get(j));
							created_status.add("Ticket Created");
							Created_priority.add(String.valueOf(priority));
						} else {
							ori_scriptname.add("-");
							ori_error_code.add("-");
							created_status.add("Ticket Created");
							Created_priority.add("-");
						}

					}
					break;

				}
			}

		}

		for (String string : collobrate_FI) {
			StringTokenizer tokens2 = new StringTokenizer(string, ":");
			while (tokens2.hasMoreTokens()) {
				ori_FI_id.add(tokens2.nextToken());
			}
		}

		if (ori_tickets.size() == ori_FI_id.size()) {
			ori_FI_id.clear();
			for (String string : collobrate_FI) {
				StringTokenizer tokens2 = new StringTokenizer(string, ":");
				while (tokens2.hasMoreTokens()) {
					ori_FI_id.add(tokens2.nextToken());
				}
			}

		}

		else if (ori_tickets.size() != ori_FI_id.size()) {
			for (int i = 0; i < counter.size(); i++) {
				for (int j = 0; j < counter.get(i); j++) {
					ori_FI_id.add(colloborate_Fi.get(i));
				}
			}

		}
//populate total tcks
		for (int i = 0; i < counter.size(); i++) {
			int number = counter.get(i) / 2;
			if (counter.get(i) > 1) {
				for (int j = 0; j < counter.get(i); j++) {
					if (number == j) {
						calc_priority.add(String.valueOf(counter.get(i)));
					} else {
						calc_priority.add(" ");
					}
				}
			} else if (counter.get(i) <= 1) {
				for (int j = 0; j < counter.get(i); j++) {

					if (j == number) {
						calc_priority.add(String.valueOf(counter.get(i)));
					}
				}

			}

		}
//calc the no of more tasks

		for (Integer moreValues : counter) {
			if (moreValues > 1) {
				greater_task++;
			}
		}

		writeprocess(ori_tickets, ori_scriptname, ori_error_code, created_status, Created_priority, counter, tasks);
	}

	private void writeprocess(ArrayList<String> ori_tickets2, ArrayList<String> ori_scriptname2,
			ArrayList<String> ori_error_code2, ArrayList<String> created_status2, ArrayList<String> created_priority2,
			ArrayList<Integer> counter2, int tasks) throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM");
		Date date = new Date();
		String today = format.format(date);
		try {
			File folder = new File("C:\\Tickets");
			if (!folder.exists()) {
				folder.mkdir();
			}

			filenames = "C:\\Tickets\\Assignment " + today + ".xlsx";

			String datenow = "";
			String overall = null;

			XSSFWorkbook book = new XSSFWorkbook();
			XSSFSheet sheet = book.createSheet("TICKETS1");
			XSSFCellStyle style = book.createCellStyle();
			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			XSSFCellStyle xSSFCellStyle1 = book.createCellStyle();
			XSSFCellStyle xSSFCellStyle7 = book.createCellStyle();
			XSSFCellStyle xSSFCellStyle2 = book.createCellStyle();
			xSSFCellStyle2.setBorderBottom(BorderStyle.THIN);
			xSSFCellStyle2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle2.setBorderRight(BorderStyle.THIN);
			xSSFCellStyle2.setRightBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle2.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			XSSFCellStyle xSSFCellStyle3 = book.createCellStyle();
			xSSFCellStyle3.setBorderBottom(BorderStyle.THIN);
			xSSFCellStyle3.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle3.setBorderRight(BorderStyle.THIN);
			xSSFCellStyle3.setRightBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle3.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			XSSFFont font = book.createFont();
			style.setAlignment((short) 2);
			XSSFRow row = sheet.createRow(0);
			List<String> headings = Head_call();
			for (int mainitr = 0; mainitr < headings.size(); mainitr++) {
				String cellname = "cell" + mainitr;
				XSSFCell xSSFCell = row.createCell(mainitr);
				xSSFCell.setCellValue(headings.get(mainitr));
				xSSFCellStyle7.setFillPattern((short) 1);
				xSSFCell.setCellStyle((CellStyle) xSSFCellStyle1);
				font.setBoldweight((short) 700);
				xSSFCellStyle7.setFont(font);
				xSSFCell.setCellStyle((CellStyle) style);
				xSSFCellStyle7.setBorderBottom(BorderStyle.THIN);
				xSSFCellStyle7.setBottomBorderColor(IndexedColors.BLACK.getIndex());
				xSSFCellStyle7.setBorderRight(BorderStyle.THIN);
				xSSFCellStyle7.setRightBorderColor(IndexedColors.BLACK.getIndex());
				xSSFCellStyle7.setBorderTop(BorderStyle.THIN);
				style.setTopBorderColor(IndexedColors.BLACK.getIndex());
				xSSFCell.setCellStyle((CellStyle) xSSFCellStyle7);
				xSSFCellStyle7.setAlignment((short) 2);
				xSSFCellStyle7.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			}

			for (int i = 0; i < ori_tickets2.size(); i++) {
				row = sheet.createRow(i + 1);
				for (int j = 0; j < 10; j++) {
					XSSFCell xSSFCell = row.createCell(j);
					if (xSSFCell.getColumnIndex() == 2) {
						xSSFCell.setCellValue(ori_tickets2.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 0) {

						if (StringUtils.equals(ori_scriptname2.get(i), "-")) {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						} else {
							xSSFCell.setCellValue(ori_scriptname2.get(i));
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}
					if (xSSFCell.getColumnIndex() == 1) {
						if (StringUtils.equals(ori_error_code2.get(i), "-")) {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						} else {
							xSSFCell.setCellValue(ori_error_code2.get(i));
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}

					if (xSSFCell.getColumnIndex() == 3) {
						xSSFCell.setCellValue(calc_priority.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 4) {
						xSSFCell.setCellValue(ori_FI_id.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 5) {
						xSSFCell.setCellValue(created_status2.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 6) {
						if (StringUtils.equals(created_priority2.get(i), "-")) {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						} else {
							xSSFCell.setCellValue((created_priority2.get(i)));
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}
					if (xSSFCell.getColumnIndex() == 7) {

						xSSFCell.setCellValue("");
						xSSFCell.setCellStyle((CellStyle) style);

					}
					if (xSSFCell.getColumnIndex() == 8) {
						if (StringUtils.containsIgnoreCase(ori_scriptname2.get(i), "Hint")) {
							xSSFCell.setCellValue("Hint Script");
							xSSFCell.setCellStyle((CellStyle) style);
							other_cnt++;

						} else {
							xSSFCell.setCellValue("");
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}

				}
			}

			row = sheet.createRow(ori_tickets2.size() + 4);
			XSSFCell xSSFCell1 = row.createCell(0);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellValue("Tasks: ");
			xSSFCellStyle3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
			xSSFCellStyle3.setFillPattern((short) 1);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			font.setBoldweight((short) 700);
			xSSFCellStyle3.setFont(font);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle3);
			String value4 = String.valueOf(tasks - 1);
			xSSFCell1 = row.createCell(1);
			xSSFCell1.setCellValue(value4);
			xSSFCell1.setCellStyle((CellStyle) style);
			taskstextField.setText(value4);
			taskstextField.setBackground(Color.GREEN);

			row = sheet.createRow(ori_tickets2.size() + 5);
			xSSFCell1 = row.createCell(0);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellValue("Tickets: ");
			xSSFCellStyle3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
			xSSFCellStyle3.setFillPattern((short) 1);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			font.setBoldweight((short) 700);
			xSSFCellStyle3.setFont(font);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle3);
			value4 = String.valueOf(ori_tickets2.size());
			xSSFCell1 = row.createCell(1);
			xSSFCell1.setCellValue(value4);
			xSSFCell1.setCellStyle((CellStyle) style);

			row = sheet.createRow(ori_tickets2.size() + 6);
			xSSFCell1 = row.createCell(0);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellValue("> than 1 ticket in task: ");
			xSSFCellStyle3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
			xSSFCellStyle3.setFillPattern((short) 1);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			font.setBoldweight((short) 700);
			xSSFCellStyle3.setFont(font);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle3);
			xSSFCell1 = row.createCell(1);
			xSSFCell1.setCellValue(String.valueOf(greater_task));
			xSSFCell1.setCellStyle((CellStyle) style);

			row = sheet.createRow(ori_tickets2.size() + 7);
			xSSFCell1 = row.createCell(0);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellValue("Others: ");
			xSSFCellStyle3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
			xSSFCellStyle3.setFillPattern((short) 1);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			font.setBoldweight((short) 700);
			xSSFCellStyle3.setFont(font);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle3);
			xSSFCell1 = row.createCell(1);
			xSSFCell1.setCellValue(String.valueOf(other_cnt));
			xSSFCell1.setCellStyle((CellStyle) style);

			for (int allign = 0; allign < 9; allign++) {
				sheet.autoSizeColumn(allign);
			}
			System.out.println(filenames);
			FileOutputStream out = new FileOutputStream(new File(filenames));

			book.write(out);
			System.out.println("!!!!!---------------FILE CREATED Successfullly---------------!!!!!");
			status.setText("SUCCESS..!!");
			status.setBackground(Color.GREEN);
			ticketsField.setText(String.valueOf(ori_tickets2.size()));
			ticketsField.setBackground(Color.GREEN);
			more_than_one.setText(String.valueOf(greater_task));
			more_than_one.setBackground(Color.green);
			others.setText(String.valueOf(other_cnt));
			others.setBackground(Color.GREEN);
			// calldetails();
			// opener(filenames);

		} catch (IndexOutOfBoundsException e) {
			calldetails();
		} catch (FileNotFoundException e) {
			status.setText("File already open");
			status.setBackground(Color.RED);
		}
	}

	private void opener(String filename) throws Exception {
		Desktop desk = Desktop.getDesktop();
		desk.open(new File(filename));

	}

	private void calldetails() {
		System.out.println("-----------------------");
		System.out.println(ori_error_code.size());
		System.out.println(ori_scriptname.size());
		System.out.println(ori_tickets.size());
		System.out.println(Created_priority.size());
		System.out.println(ori_FI_id.size());
		System.out.println(counter.size());
		status.setText("Something Went Wrong");
		status.setBackground(Color.RED);

	}

	protected static List<String> Head_call() {
		headings.add("SCRIPT NAME");
		headings.add("ERROR CODE");
		headings.add("TICKET ID");
		headings.add("TOTAL TICKETS");
		headings.add("FI ID");
		headings.add("TASK STATUS");
		headings.add("PRIORITY");
		headings.add("ASSIGNED TO");
		headings.add("COMMENTS");
		return headings;
	}

	public File_chooser() {
		initialize();
	}

	public static String openWindow() throws Exception {
		File file = null;
		JFileChooser chooser = new JFileChooser("C:");
		StringBuffer sb = new StringBuffer();
		if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile();

			Scanner scr = new Scanner(file);
			while (scr.hasNext()) {
				sb.append(scr.nextLine()).append(System.lineSeparator());

			}
		}
		String filename = String.valueOf(file);
		return filename;
	}

	private void initialize() {
		frame = new JFrame("Backup Starter Initialized.... >>>");
		frame.getContentPane().setBackground(new Color(153, 204, 204));
		frame.setBounds(100, 100, 689, 334);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		FilePathname = new JTextField();
		FilePathname.setFont(new Font("Tahoma", Font.BOLD, 13));
		FilePathname.setBackground(SystemColor.menu);
		FilePathname.setBounds(99, 77, 288, 22);
		frame.getContentPane().add(FilePathname);
		FilePathname.setColumns(10);

		JLabel lblNewLabel = new JLabel("File path :");
		lblNewLabel.setBounds(12, 80, 104, 16);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel);

		JButton btnNewButton = new JButton("Analyse ");
		btnNewButton.setBackground(SystemColor.menu);
		btnNewButton.setBounds(391, 76, 97, 25);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!FilePathname.getText().isEmpty()) {
					try {
						begin(FilePathname.getText().trim());
					} catch (Exception e) {

						e.printStackTrace();
					}
				}

			}

		});
		frame.getContentPane().add(btnNewButton);

		status = new JTextField();
		status.setBackground(SystemColor.menu);
		status.setBounds(400, 240, 257, 22);
		status.setForeground(SystemColor.desktop);
		status.setHorizontalAlignment(SwingConstants.CENTER);
		status.setFont(new Font("Tahoma", Font.BOLD, 12));
		frame.getContentPane().add(status);
		status.setColumns(10);

		lblNewLabel_1 = new JLabel("Status :");
		lblNewLabel_1.setBounds(342, 242, 56, 16);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel_1);

		ticketsField = new JTextField();
		ticketsField.setBackground(SystemColor.menu);
		ticketsField.setBounds(282, 180, 89, 22);
		ticketsField.setForeground(SystemColor.desktop);
		ticketsField.setFont(new Font("Tahoma", Font.BOLD, 12));
		ticketsField.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(ticketsField);
		ticketsField.setColumns(10);

		lblNewLabel_2 = new JLabel("Tickets :");
		lblNewLabel_2.setBounds(208, 182, 89, 16);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel_2);

		lblNewLabel_3 = new JLabel("BACKUP ASSIGNER");
		lblNewLabel_3.setBounds(238, 13, 184, 25);
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.BLUE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		frame.getContentPane().add(lblNewLabel_3);

		JSeparator separator = new JSeparator();
		separator.setBounds(672, 120, -673, 2);
		frame.getContentPane().add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 140, 671, 2);
		frame.getContentPane().add(separator_1);

		lblNewLabel_4 = new JLabel("Tasks :");
		lblNewLabel_4.setBounds(29, 182, 56, 16);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel_4);

		taskstextField = new JTextField();
		taskstextField.setBackground(SystemColor.menu);
		taskstextField.setBounds(82, 180, 89, 22);
		taskstextField.setFont(new Font("Tahoma", Font.BOLD, 12));
		taskstextField.setHorizontalAlignment(SwingConstants.CENTER);
		taskstextField.setForeground(SystemColor.desktop);
		frame.getContentPane().add(taskstextField);
		taskstextField.setColumns(10);

		separator_2 = new JSeparator();
		separator_2.setBounds(174, 195, 0, -68);
		frame.getContentPane().add(separator_2);

		JButton btnNewButton_1 = new JButton("Upload ^");
		btnNewButton_1.setBackground(SystemColor.menu);
		btnNewButton_1.setBounds(549, 76, 101, 25);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {
					String name = openWindow();
					System.out.println(name);
					begin(name.trim());
				} catch (Exception e) {

					e.printStackTrace();
				}
			}
		});
		frame.getContentPane().add(btnNewButton_1);

		more_than_one = new JTextField();
		more_than_one.setBackground(SystemColor.menu);
		more_than_one.setFont(new Font("Tahoma", Font.BOLD, 12));
		more_than_one.setHorizontalAlignment(SwingConstants.CENTER);
		more_than_one.setBounds(549, 179, 91, 22);
		frame.getContentPane().add(more_than_one);
		more_than_one.setColumns(10);

		lblNewLabel_5 = new JLabel("> 1 tickets in Task :");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(383, 182, 186, 16);
		frame.getContentPane().add(lblNewLabel_5);

		others = new JTextField();
		others.setBackground(SystemColor.menu);
		others.setFont(new Font("Tahoma", Font.BOLD, 12));
		others.setHorizontalAlignment(SwingConstants.CENTER);
		others.setBounds(85, 239, 89, 22);
		frame.getContentPane().add(others);
		others.setColumns(10);

		lblNewLabel_6 = new JLabel("Others :");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(29, 242, 56, 16);
		frame.getContentPane().add(lblNewLabel_6);

		JButton opener = new JButton(">");
		opener.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					opener(filenames);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		opener.setBounds(496, 78, 41, 21);
		frame.getContentPane().add(opener);

	}
}
