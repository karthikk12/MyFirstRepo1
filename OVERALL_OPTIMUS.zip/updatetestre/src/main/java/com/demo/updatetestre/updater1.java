package com.demo.updatetestre;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;

import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class updater1 extends MyScriptFrame {
  static CloseableHttpClient clients = HttpClients.createDefault();
  
  static List<String> previous_tcks = new ArrayList<>();
  
  static StringBuffer sb = new StringBuffer();
  
  static StringBuilder newstate = new StringBuilder();
  
  static StringBuffer totaltickets = new StringBuffer();
  
  static List<String> demoupdstatus = new ArrayList<>();
  
  static List<String> finalupdstatus = new ArrayList<>();
  
  static List<String> sepline = new ArrayList<>();
  
  static List<String> hrefvalues = new ArrayList<>();
  
  static List<String> ahreftag = new ArrayList<>();
  
  static List<String> demotcks = new ArrayList<>();
  
  static List<String> tickets = new ArrayList<>();
  
  static List<String> script_name = new ArrayList<>();
  
  static List<String> upd_ticketNo = new ArrayList<>();
  
  static List<String> upd_scriptName = new ArrayList<>();
  
  static List<String> upd_errorCode = new ArrayList<>();
  
  static List<String> upd_grade = new ArrayList<>();
  
  static List<String> upd_Createdstatus = new ArrayList<>();
  
  static List<String> upd_assigneename = new ArrayList<>();
  
  static List<String> teammembers = new ArrayList<>();
  
  static List<String> errorcode = new ArrayList<>();
  
  static List<Integer> Grade = new ArrayList<>();
  
  static List<String> headings = new ArrayList<>();
  
  static List<String> Countcalc = new ArrayList<>();
  
  static List<String> Created_status = new ArrayList<>();
  
  static List<String> assignee_name = new ArrayList<>();
  
  static final String MAIN_URL = "http://172.22.106.43:8087/tasks";
  
  static final String INNER_URL = "http://172.22.106.43:8087/tasks/internal";
  
  static Map<Integer, String> mymap = new HashMap<>();
  
  static StringBuffer xpathbuffer = new StringBuffer();
  
  static List<String> scriptstore = new ArrayList<>();
  
  static String[] myarray = new String[500];
  
  static int retrycount = 1;
  
  static int other_cnt = 0;
  
  static int rem_value;
  
  private JFrame frame;
  
  private static JTextField inputfiletext;
  
  private static JTextField lblFilePath;
  
  private static JTextField ticketscountsfields;
  
  private static JTextField otherfields;
  
  private static JTextField allotedfield;
  
  private static JTextField statusfield;
  
  private static JTextField messagefields;
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            try {
              updater1 windows = new updater1();
              windows.frame.setVisible(true);
            } catch (Exception e) {
              e.printStackTrace();
            } 
          }
        });
  }
  
  private static void postdatas(int responsecode, String manager, String developer) throws ParserConfigurationException, Exception {
    GetMethod getMethods = new GetMethod();
    HttpClient httpClient = new HttpClient();
    PostMethod postMethod = new PostMethod("http://172.22.106.43:8087/tasks/internal");
    postMethod.addParameter("selectedManager", manager);
    postMethod.addParameter("SelectedDeveloper", developer);
    httpClient.executeMethod((HttpMethod)postMethod);
    String getresbody = new String(postMethod.getResponseBody());
    if (StringUtils.isEmpty(getresbody)) {
      System.out.println("Reponse body is Empty");
      System.exit(0);
    } else {
      System.out.println("Successfully Connected : ----------> " + responsecode + "%");
      System.out.println("");
      validation(getresbody, manager, developer);
      statusfield.setText("SUCCESS");
      statusfield.setBackground(Color.GREEN);
    } 
  }
  
  private static void separate_it(String getlines, String local_copy, String manager, String developer) throws ParserConfigurationException, Exception {
    int count = 0;
    int counter = 0;
    int i = 0;
    Scanner scs1 = new Scanner(getlines);
    while (scs1.hasNext()) {
      String lines = scs1.nextLine();
      if (!lines.isEmpty())
        count++; 
    } 
    sb.delete(0, sb.length());
    Scanner scs2 = new Scanner(getlines);
    while (scs2.hasNext()) {
      boolean check = scs2.hasNext();
      String element = scs2.nextLine();
      if (check) {
        sb.append(element).append(System.lineSeparator());
        if (StringUtils.equalsIgnoreCase(element, "open") || 
          StringUtils.containsIgnoreCase(element, "in Progress") || 
          StringUtils.containsIgnoreCase(element, "Closed") || 
          StringUtils.containsIgnoreCase(element, "Done")) {
          myarray[counter++] = sb.toString();
          sb.delete(0, sb.length());
        } 
      } 
    } 
    for (int j = 0; j < myarray.length - 1; j++) {
      String linechck = myarray[j];
      if (!StringUtils.isEmpty(linechck))
        sepline.add(linechck); 
    } 
    sb.delete(0, sb.length());
    for (int ctr = 0; ctr < sepline.size(); ctr++) {
      int counts = 0;
      Scanner scs3 = new Scanner(sepline.get(ctr));
      while (scs3.hasNext()) {
        String eachline = scs3.nextLine();
        counts++;
        if (counts == 2 || counts == 5 || counts == 9 || counts == 11)
          sb.append(eachline).append("-"); 
      } 
      mymap.put(Integer.valueOf(ctr), sb.toString());
      sb.delete(0, sb.length());
    } 
    Iterator<Integer> mapit = mymap.keySet().iterator();
    while (mapit.hasNext()) {
      int index = ((Integer)mapit.next()).intValue();
      String values = mymap.get(Integer.valueOf(index));
      scriptstore.add(values);
    } 
    sb.delete(0, sb.length());
    filter_tcks(local_copy, mymap, manager, developer);
  }
  
  private static void list_it(String response, int count, String local_copy, String manager, String developer) throws ParserConfigurationException, Exception {
    sb.delete(0, sb.length());
    sb.append("<html>").append(System.lineSeparator()).append("<body>").append(System.lineSeparator())
      .append(response).append(System.lineSeparator()).append("</body>").append(System.lineSeparator())
      .append("</html>");
    String res = sb.toString();
    sb.delete(0, sb.length());
    String result = myXpathEvaluationObject(res, "/html/body");
    Scanner scs = new Scanner(result);
    while (scs.hasNext()) {
      String lines = scs.nextLine();
      if (!lines.isEmpty()) {
        sb.append(lines);
        sb.append(System.lineSeparator());
      } 
    } 
    separate_it(sb.toString(), local_copy, manager, developer);
  }
  
  private static void filter_tcks(String local_copy, Map mymap, String manager, String developer) throws ParserConfigurationException, Exception {
    String refvalue = "";
    String cutter = StringUtils.substringBetween(local_copy, "select-checkbox", "</body>");
    sb.append("<html>").append(System.lineSeparator()).append("<body>").append(System.lineSeparator())
      .append(cutter).append(System.lineSeparator()).append("</body>").append(System.lineSeparator())
      .append("</html>");
    String tck_copy = sb.toString();
    sb.delete(0, sb.length());
    Scanner scs4 = new Scanner(tck_copy);
    while (scs4.hasNext()) {
      String lines = scs4.nextLine();
      if (StringUtils.containsIgnoreCase(lines, "<a href")) {
        sb.append(lines).append(System.lineSeparator());
        String passer = sb.toString();
        hrefvalues.add(passer);
        sb.delete(0, sb.length());
      } 
    } 
    sb.delete(0, sb.length());
    tckt_seperator(hrefvalues, mymap, local_copy, manager, developer);
  }
  
  private static void looper_err_scr(String local_copy, List tickets, List hrefvalues, Map mymap, List ahreftag, List created_status, List assigne_name, String manager, String developer) throws Exception {
    String scriptname = "";
    String error_code = "";
    String react_counts = "";
    String pro_counts = "";
    int gradeno = 0;
    String[] teamnames = new String[4];
    int tercounter = 0;
    teamnames[0] = "Mohan";
    teamnames[1] = "Balaji";
    teamnames[2] = "Karthik";
    teamnames[3] = "Vignesh";
    for (int itr = 0; itr < scriptstore.size(); itr++) {
      tercounter++;
      if (tercounter == 4)
        tercounter = 0; 
      gradeno++;
      String names = scriptstore.get(itr);
      StringTokenizer tokenize = new StringTokenizer(names, "-");
      while (tokenize.hasMoreTokens()) {
        scriptname = tokenize.nextToken();
        error_code = tokenize.nextToken();
        pro_counts = tokenize.nextToken();
        react_counts = tokenize.nextToken();
      } 
      int pro_number_count = converttoValidNumber(pro_counts);
      int react_number_count = converttoValidNumber(react_counts);
      if (react_number_count == 0) {
        for (int ctr = 0; ctr < pro_number_count; ctr++) {
          script_name.add(scriptname);
          errorcode.add(error_code);
          Grade.add(Integer.valueOf(gradeno));
          teammembers.add(teamnames[tercounter]);
        } 
      } else if (pro_number_count == 0) {
        for (int ctr = 0; ctr < react_number_count; ctr++) {
          script_name.add(scriptname);
          errorcode.add(error_code);
          Grade.add(Integer.valueOf(gradeno));
          teammembers.add(teamnames[tercounter]);
        } 
      } else {
        for (int proctr = 0; proctr < pro_number_count; proctr++) {
          script_name.add(scriptname);
          errorcode.add(error_code);
          Grade.add(Integer.valueOf(gradeno));
          teammembers.add(teamnames[tercounter]);
        } 
        for (int reactr = 0; reactr < react_number_count; reactr++) {
          script_name.add(scriptname);
          errorcode.add(error_code);
          Grade.add(Integer.valueOf(gradeno));
          teammembers.add(teamnames[tercounter]);
        } 
      } 
    } 
    Comparator(tickets, Created_status, assignee_name, script_name, Grade, errorcode, manager, developer);
  }
  
  private static void assigneeName_Status(String local_copy, List tickets, List hrefvalues, Map mymap, List<String> ahreftag, String manager, String developer) throws ParserConfigurationException, Exception {
    int cnt = 0;
    int main_cnt = 0;
    sb.delete(0, sb.length());
    String refvalue = "";
    String cutter = StringUtils.substringBetween(local_copy, "select-checkbox", "</body>");
    sb.append("<html>").append(System.lineSeparator()).append("<body>").append(System.lineSeparator())
      .append(cutter).append(System.lineSeparator()).append("</body>").append(System.lineSeparator())
      .append("</html>");
    String tck_copys = sb.toString();
    for (int index = 0; index < ahreftag.size(); index++) {
      String lines = ahreftag.get(index);
      String getlines = lines.trim();
      String cutlines = StringUtils.substringBetween(tck_copys, getlines, "</tr>");
      demotcks.add(cutlines);
    } 
    for (int itr = 0; itr < demotcks.size(); itr++) {
      cnt = 0;
      String iterator = demotcks.get(itr);
      Scanner scs6 = new Scanner(iterator);
      while (scs6.hasNext()) {
        String eachline = scs6.nextLine();
        cnt++;
        if (cnt == 94) {
          String cutnew = StringUtils.substringBetween(eachline, ">", "</");
          String trim_created_status = cutnew.trim();
          Created_status.add(trim_created_status);
        } 
        if (cnt == 87) {
          String cutnew2 = StringUtils.substringBetween(eachline, ">", "</");
          String trim_assigne = cutnew2.trim();
          assignee_name.add(trim_assigne);
        } 
      } 
    } 
    looper_err_scr(local_copy, tickets, hrefvalues, mymap, ahreftag, Created_status, assignee_name, manager, 
        developer);
  }
  
  private static void Comparator(List tickets, List Created_status, List assignee_name, List script_name, List Grade, List<String> errorcode, String manager, String developer) throws Exception {
    for (int i = 0; i < tickets.size(); i++) {
      newstate.append(tickets.get(i)).append("-").append(script_name.get(i)).append("-").append(errorcode.get(i))
        .append("-").append(Created_status.get(i)).append("-").append(Grade.get(i)).append("-")
        .append(assignee_name.get(i));
      String overallstring = newstate.toString();
      newstate.delete(0, newstate.length());
      demoupdstatus.add(overallstring);
    } 
    int prevtck = previous_tcks.size();
    int updstate = demoupdstatus.size();
    if (prevtck < updstate) {
      int calc = updstate - prevtck;
      for (int k = 0; k < calc; k++)
        previous_tcks.add("None"); 
    } else if (prevtck > updstate) {
      int calc = prevtck - updstate;
      for (int k = 0; k < calc; k++)
        demoupdstatus.add("None"); 
    } else if (prevtck == updstate) {
      System.out.println("No Files Changed");
    } 
    int j;
    for (j = 0; j < previous_tcks.size(); j++) {
      for (int k = 0; k < demoupdstatus.size(); k++) {
        String previoustckt = previous_tcks.get(j);
        String updstatus = demoupdstatus.get(k);
        if (updstatus.contains(previoustckt))
          demoupdstatus.remove(k); 
      } 
    } 
    for (j = 0; j < demoupdstatus.size(); j++) {
      if (!StringUtils.containsIgnoreCase(demoupdstatus.get(j), "none"))
        finalupdstatus.add(demoupdstatus.get(j)); 
    } 
    if (!finalupdstatus.isEmpty()) {
      finalupdstatus.forEach(name -> System.out.println(name));
    } else {
      System.out.println("No files Changed");
    } 
    for (int ctr = 0; ctr < finalupdstatus.size(); ctr++) {
      String eachone = finalupdstatus.get(ctr);
      StringTokenizer tokeniser = new StringTokenizer(eachone, "-");
      while (tokeniser.hasMoreTokens()) {
        String updtckno = tokeniser.nextToken();
        String updscriptname = tokeniser.nextToken();
        String upderrcode = tokeniser.nextToken();
        String updcreatedstatus = tokeniser.nextToken();
        String updgrade = tokeniser.nextToken();
        String updassignee = tokeniser.nextToken();
        upd_ticketNo.add(updtckno);
        upd_scriptName.add(updscriptname);
        upd_errorCode.add(upderrcode);
        upd_Createdstatus.add(updcreatedstatus);
        upd_grade.add(updgrade);
        upd_assigneename.add(updassignee);
      } 
    } 
    write_process(upd_ticketNo, upd_scriptName, upd_errorCode, upd_Createdstatus, upd_grade, upd_assigneename, 
        manager, developer);
  }
  
  private static void write_process(List upd_ticketNo, List upd_scriptName, List upd_errorCode, List upd_Createdstatus, List upd_grade, List upd_assigneename, String manager, String developer) throws IOException {
    SimpleDateFormat sdf = new SimpleDateFormat("MMM-dd");
    SimpleDateFormat sdf1 = new SimpleDateFormat("HH:ss");
    Date date1 = new Date();
    Date date2 = new Date();
    String datenow = sdf.format(date1);
    String secnow = sdf1.format(date2);
    String s_name = "snagarajan1";
    String k_name = "kbaskaran";
    String v_name = "vbalakrishn";
    String m_name = "mjayaraj";
    String b_name = "ssampathkum";
    String s_ori_name = "Saraswathi";
    String k_ori_name = "Karthik";
    String v_ori_name = "Vignesh";
    String m_ori_name = "Mohan";
    String b_ori_name = "Balaji";
    int kcount = 0;
    int mcount = 0;
    int scount = 0;
    int bcount = 0;
    int vcount = 0;
    String successmessage = "FILE CREATED SUCCESSFULLY";
    String default_name = "System";
    int ticket_size = upd_ticketNo.size();
    int errcode_size = upd_errorCode.size();
    int cr_status = upd_Createdstatus.size();
    int assignestatus_size = upd_assigneename.size();
    int grade_size = upd_grade.size();
    int total = 12;
    try {
      XSSFWorkbook book = new XSSFWorkbook();
      XSSFSheet sheet = book.createSheet("Updated TICKETS");
      XSSFCellStyle style = book.createCellStyle();
      XSSFCellStyle xSSFCellStyle1 = book.createCellStyle();
      XSSFCellStyle xSSFCellStyle2 = book.createCellStyle();
      XSSFCellStyle xSSFCellStyle3 = book.createCellStyle();
      XSSFFont font = book.createFont();
      style.setAlignment((short)2);
      XSSFRow row = sheet.createRow(0);
      List<String> headings = Head_call();
      for (int mainitr = 0; mainitr < headings.size(); mainitr++) {
        String cellname = "cell" + mainitr;
        XSSFCell xSSFCell = row.createCell(mainitr);
        xSSFCell.setCellValue(headings.get(mainitr));
        xSSFCellStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        xSSFCellStyle1.setFillPattern((short)1);
        xSSFCell.setCellStyle((CellStyle)xSSFCellStyle1);
        font.setBoldweight((short)700);
        xSSFCellStyle1.setFont(font);
        xSSFCell.setCellStyle((CellStyle)style);
        xSSFCell.setCellStyle((CellStyle)xSSFCellStyle1);
      } 
      if (ticket_size == errcode_size && ticket_size == cr_status && ticket_size == assignestatus_size && 
        ticket_size == errcode_size) {
        for (int i = 0; i < upd_ticketNo.size(); i++) {
          row = sheet.createRow(i + 1);
          for (int j = 0; j < 7; j++) {
            XSSFCell xSSFCell = row.createCell(j);
            if (xSSFCell.getColumnIndex() == 0) {
              xSSFCell.setCellValue(updater1.upd_ticketNo.get(i));
              xSSFCell.setCellStyle((CellStyle)style);
            } 
            if (xSSFCell.getColumnIndex() == 1) {
              xSSFCell.setCellValue(updater1.upd_scriptName.get(i));
              xSSFCell.setCellStyle((CellStyle)style);
            } 
            if (xSSFCell.getColumnIndex() == 2) {
              xSSFCell.setCellValue(updater1.upd_errorCode.get(i));
              xSSFCell.setCellStyle((CellStyle)style);
            } 
            if (xSSFCell.getColumnIndex() == 3) {
              xSSFCell.setCellValue(updater1.upd_Createdstatus.get(i));
              xSSFCell.setCellStyle((CellStyle)style);
            } 
            if (xSSFCell.getColumnIndex() == 4) {
              xSSFCell.setCellValue(updater1.upd_grade.get(i));
              xSSFCell.setCellStyle((CellStyle)style);
            } 
            if (xSSFCell.getColumnIndex() == 5) {
              xSSFCell.setCellValue(updater1.upd_assigneename.get(i));
              xSSFCell.setCellStyle((CellStyle)style);
            } 
            if (xSSFCell.getColumnIndex() == 5)
              if (StringUtils.containsIgnoreCase(updater1.upd_scriptName.get(i), 
                  "q2tower_api2.scr")) {
                scount++;
                xSSFCell.setCellValue(s_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  m_name)) {
                mcount++;
                xSSFCell.setCellValue(m_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  v_name)) {
                vcount++;
                xSSFCell.setCellValue(v_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  k_name)) {
                kcount++;
                xSSFCell.setCellValue(k_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  b_name)) {
                bcount++;
                xSSFCell.setCellValue(b_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_Createdstatus.get(i), 
                  "In progress") && 
                StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  b_name)) {
                bcount++;
                xSSFCell.setCellValue(b_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_Createdstatus.get(i), 
                  "In progress") && 
                StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  k_name)) {
                kcount++;
                xSSFCell.setCellValue(k_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_Createdstatus.get(i), 
                  "In progress") && 
                StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  v_name)) {
                vcount++;
                xSSFCell.setCellValue(b_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_Createdstatus.get(i), 
                  "In progress") && 
                StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  s_name)) {
                scount++;
                xSSFCell.setCellValue(s_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_Createdstatus.get(i), 
                  "In progress") && 
                StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), 
                  m_name)) {
                mcount++;
                xSSFCell.setCellValue(m_ori_name);
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_assigneename.get(i), "System") && 
                !StringUtils.containsIgnoreCase(updater1.upd_scriptName.get(i), 
                  "q2tower_api2.scr")) {
                xSSFCell.setCellValue(teammembers.get(i));
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_scriptName.get(i), "hint")) {
                other_cnt++;
                xSSFCell.setCellValue("Hint Script");
                xSSFCell.setCellStyle((CellStyle)style);
              }  
            if (xSSFCell.getColumnIndex() == 6)
              if (!StringUtils.equalsIgnoreCase(updater1.upd_assigneename.get(i), s_name) && 
                !StringUtils.equalsIgnoreCase(updater1.upd_assigneename.get(i), m_name) && 
                !StringUtils.equalsIgnoreCase(updater1.upd_assigneename.get(i), k_name) && 
                !StringUtils.equalsIgnoreCase(updater1.upd_assigneename.get(i), v_name) && 
                !StringUtils.equalsIgnoreCase(updater1.upd_assigneename.get(i), b_name) && 
                !StringUtils.equalsIgnoreCase(updater1.upd_assigneename.get(i), 
                  default_name)) {
                other_cnt++;
                xSSFCell.setCellValue("Assigned By IL Team");
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.equalsIgnoreCase(updater1.upd_errorCode.get(i), "999")) {
                other_cnt++;
                xSSFCell.setCellValue("Bank Statements");
                xSSFCell.setCellStyle((CellStyle)style);
              } else if (StringUtils.containsIgnoreCase(updater1.upd_scriptName.get(i), "hint")) {
                other_cnt++;
                xSSFCell.setCellValue("Hint Script");
                xSSFCell.setCellStyle((CellStyle)style);
              }  
          } 
        } 
        for (int allign = 0; allign < total; allign++)
          sheet.autoSizeColumn(allign); 
        row = sheet.createRow(upd_ticketNo.size() + 5);
        XSSFCell xSSFCell1 = row.createCell(0);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellValue("New Upd Tickets : ");
        xSSFCellStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        xSSFCellStyle1.setFillPattern((short)1);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        font.setBoldweight((short)700);
        xSSFCellStyle1.setFont(font);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        XSSFCell xSSFCell2 = row.createCell(1);
        xSSFCell2.setCellValue(upd_ticketNo.size());
        xSSFCell2.setCellStyle((CellStyle)style);
        String value1 = String.valueOf(upd_ticketNo.size());
        ticketscountsfields.setText(value1);
        ticketscountsfields.setBackground(Color.GREEN);
        if (upd_ticketNo.size() > 0) {
          allotedfield.setText("Yes");
          allotedfield.setBackground(Color.GREEN);
        } else if (upd_ticketNo.size() == 0) {
          allotedfield.setText("No");
          allotedfield.setBackground(Color.RED);
        } 
        row = sheet.createRow(upd_ticketNo.size() + 6);
        xSSFCell1 = row.createCell(0);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellValue("Others : ");
        xSSFCellStyle2.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        xSSFCellStyle2.setFillPattern((short)1);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        font.setBoldweight((short)700);
        xSSFCellStyle2.setFont(font);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle2);
        xSSFCell2 = row.createCell(1);
        xSSFCell2.setCellValue(other_cnt);
        xSSFCell2.setCellStyle((CellStyle)style);
        String value2 = String.valueOf(other_cnt);
        otherfields.setText(value2);
        otherfields.setBackground(Color.YELLOW);
        row = sheet.createRow(upd_ticketNo.size() + 7);
        xSSFCell1 = row.createCell(0);
        xSSFCell1.setCellStyle((CellStyle)style);
        rem_value = ticket_size - other_cnt;
        xSSFCell1.setCellValue("Need to Work : ");
        xSSFCellStyle3.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
        xSSFCellStyle3.setFillPattern((short)1);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        font.setBoldweight((short)700);
        xSSFCellStyle3.setFont(font);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle3);
        String value3 = String.valueOf(rem_value);
        xSSFCell2 = row.createCell(1);
        xSSFCell2.setCellValue(rem_value);
        xSSFCell2.setCellStyle((CellStyle)style);
        row = sheet.createRow(upd_ticketNo.size() + 9);
        xSSFCell1 = row.createCell(0);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellValue("Manager : ");
        xSSFCellStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        xSSFCellStyle1.setFillPattern((short)1);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        font.setBoldweight((short)700);
        xSSFCellStyle1.setFont(font);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        xSSFCell2 = row.createCell(1);
        xSSFCell2.setCellValue(manager);
        xSSFCell2.setCellStyle((CellStyle)style);
        row = sheet.createRow(upd_ticketNo.size() + 10);
        xSSFCell1 = row.createCell(0);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellValue("Developer : ");
        xSSFCellStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        xSSFCellStyle1.setFillPattern((short)1);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        font.setBoldweight((short)700);
        xSSFCellStyle1.setFont(font);
        xSSFCell1.setCellStyle((CellStyle)style);
        xSSFCell1.setCellStyle((CellStyle)xSSFCellStyle1);
        xSSFCell2 = row.createCell(1);
        xSSFCell2.setCellValue(developer);
        xSSFCell2.setCellStyle((CellStyle)style);
        String filenames = "C:\\Tickets\\Updated Assignment  " + datenow + ".xlsx";
        FileOutputStream out = new FileOutputStream(new File(filenames));
        book.write(out);
        System.out.println("Created Path : " + filenames);
        System.out.println("");
        System.out.println("!!!!...............FILE CREATED SUCCESSFULLY.................!!!");
        messagefields.setText(filenames);
        messagefields.setBackground(Color.GREEN);
      } else {
        System.out.println("Sizes are not equal............Please check");
        System.out.println("");
        messagefields.setText("Something Wrong");
        messagefields.setBackground(Color.RED);
      } 
    } catch (FileNotFoundException e) {
      messagefields.setText("File is already Open..Please Close it");
      messagefields.setBackground(Color.RED);
      System.out.println("ERROR ::--->" + e);
      System.out.println(
          "Message ::---->The File is already in Open state.....Please close it and run the program");
    } 
  }
  
  private static void validation(String response, String manager, String developer) throws ParserConfigurationException, Exception {
    String local_copy = response;
    int count = 0;
    String result = StringUtils.substringBetween(response, "<tbody>", "</tbody>");
    Scanner total_tckts = new Scanner(result);
    while (total_tckts.hasNext()) {
      String no_of_tcs = total_tckts.nextLine();
      String trimres = trim(no_of_tcs);
      sb.append(trimres).append(System.lineSeparator());
      if (StringUtils.containsIgnoreCase(trimres, "<th>"))
        count++; 
    } 
    list_it(sb.toString(), count, local_copy, manager, developer);
  }
  
  private static void tckt_seperator(List<String> hrefvalues, Map mymap, String local_copy, String manager, String developer) throws ParserConfigurationException, Exception {
    String values = "";
    for (int index = 0; index < hrefvalues.size(); index++) {
      String getvalues = hrefvalues.get(index);
      ahreftag.add(getvalues);
      values = myXpathEvaluationObject(getvalues, "//*[@href]");
      tickets.add(values);
    } 
    category(tickets, hrefvalues, mymap, local_copy, ahreftag, manager, developer);
  }
  
  private static void category(List tickets, List hrefvalues, Map mymap, String local_copy, List ahreftag, String manager, String developer) throws ParserConfigurationException, Exception {
    Iterator<Integer> it1 = mymap.keySet().iterator();
    while (it1.hasNext()) {
      int key = ((Integer)it1.next()).intValue();
      String str = (String)mymap.get(Integer.valueOf(key));
    } 
    sb.delete(0, sb.length());
    assigneeName_Status(local_copy, tickets, hrefvalues, mymap, ahreftag, manager, developer);
  }
  
  public static void begin(String filename, String manager, String developer) throws Exception {
    StringBuffer sb1 = new StringBuffer();
    sb1.append(String.valueOf(filename) + ".xlsx");
    InputStream input = new FileInputStream(sb1.toString());
    int ctr = 1;
    Workbook wb = WorkbookFactory.create(input);
    Sheet sheet = wb.getSheetAt(0);
    Row row = null;
    Cell cell = null;
    boolean isNull = false;
    do {
      try {
        row = sheet.getRow(ctr++);
        cell = row.getCell(0);
        previous_tcks.add(cell.toString());
      } catch (Exception e) {
        isNull = true;
      } 
    } while (!isNull);
    input.close();
    initialise(manager, developer);
  }
  
  private static List<String> Head_call() {
    headings.add("TICKET CREATED");
    headings.add("SCRIPT NAME");
    headings.add("ERROR CODE");
    headings.add("STATUS");
    headings.add("PRIORITY");
    headings.add("ASSIGNED TO");
    headings.add("COMMENTS");
    return headings;
  }
  
  private static void initialise(String manager, String developer) throws Exception {
    HttpGet get = new HttpGet("http://172.22.106.43:8087/tasks");
    CloseableHttpResponse closeableHttpResponse = clients.execute((HttpUriRequest)get);
    int rescode = closeableHttpResponse.getStatusLine().getStatusCode();
    if (rescode == 200) {
      Scanner sc = new Scanner(closeableHttpResponse.getEntity().getContent());
      while (sc.hasNext()) {
        sb.append(sc.nextLine());
        sb.append(System.lineSeparator());
      } 
    } else {
      if (retrycount == 2) {
        System.out.println("Please check the Main URL....");
        System.exit(0);
      } 
      System.out.println("Retrying count : " + retrycount++);
      initialise(manager, developer);
    } 
    sb.delete(0, sb.length());
    postdatas(rescode, manager, developer);
  }
  
  public updater1() {
    initialize();
  }
  
  private void initialize() {
    this.frame = new JFrame("STARTING >>>> Checking Updates");
    this.frame.setBackground(new Color(51, 153, 204));
    this.frame.getContentPane().setBackground(new Color(153, 204, 204));
    this.frame.getContentPane().setForeground(Color.CYAN);
    this.frame.setBounds(100, 100, 848, 480);
    this.frame.setDefaultCloseOperation(3);
    final JCheckBox shrl = new JCheckBox("Shirel");
    shrl.setForeground(Color.RED);
    shrl.setFont(new Font("Tahoma", 3, 12));
    shrl.setBounds(384, 83, 97, 23);
    this.frame.getContentPane().add(shrl);
    final JCheckBox COGAL = new JCheckBox("Cognizant Alaska");
    COGAL.setForeground(Color.RED);
    COGAL.setFont(new Font("Tahoma", 3, 12));
    COGAL.setBounds(146, 146, 150, 23);
    this.frame.getContentPane().add(COGAL);
    final JCheckBox all = new JCheckBox("All");
    all.setForeground(Color.RED);
    all.setFont(new Font("Tahoma", 3, 12));
    all.setBounds(645, 146, 97, 23);
    this.frame.getContentPane().add(all);
    JSeparator separator = new JSeparator();
    separator.setBounds(-80, 113, 922, 26);
    this.frame.getContentPane().add(separator);
    JLabel lblTask = new JLabel("UPDATER #C4");
    lblTask.setHorizontalAlignment(0);
    lblTask.setBackground(new Color(0, 255, 255));
    lblTask.setForeground(Color.BLACK);
    lblTask.setFont(new Font("Verdana", 1, 15));
    lblTask.setBounds(297, 27, 231, 23);
    this.frame.getContentPane().add(lblTask);
    JLabel lblManager = new JLabel("Manager :");
    lblManager.setFont(new Font("Verdana", 1, 11));
    lblManager.setBounds(309, 87, 86, 14);
    this.frame.getContentPane().add(lblManager);
    JSeparator separator_1 = new JSeparator();
    separator_1.setBounds(445, 120, 1, 164);
    this.frame.getContentPane().add(separator_1);
    JLabel lblDeveloper = new JLabel("Developer :");
    lblDeveloper.setFont(new Font("Verdana", 1, 11));
    lblDeveloper.setBounds(70, 150, 86, 14);
    this.frame.getContentPane().add(lblDeveloper);
    JLabel lblDeveloper_1 = new JLabel("Developer : ");
    lblDeveloper_1.setFont(new Font("Verdana", 1, 11));
    lblDeveloper_1.setBounds(566, 150, 87, 14);
    this.frame.getContentPane().add(lblDeveloper_1);
    inputfiletext = new JTextField();
    inputfiletext.setBounds(325, 239, 313, 20);
    this.frame.getContentPane().add(inputfiletext);
    inputfiletext.setColumns(10);
    String name = inputfiletext.getText();
    JLabel lblFilePath = new JLabel("Path + File Name :");
    lblFilePath.setFont(new Font("Tahoma", 1, 11));
    lblFilePath.setHorizontalAlignment(0);
    lblFilePath.setBounds(198, 242, 136, 14);
    this.frame.getContentPane().add(lblFilePath);
    JButton btnNewButton = new JButton("Update");
    btnNewButton.setFont(new Font("Tahoma", 1, 11));
    btnNewButton.setForeground(Color.BLACK);
    btnNewButton.setBounds(414, 270, 89, 23);
    btnNewButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (shrl.isSelected() && COGAL.isSelected() && !updater1.inputfiletext.getText().isEmpty()) {
              String manager = "Shirel";
              String developer = "Cognizant-Alaska";
              try {
                updater1.begin(updater1.inputfiletext.getText().toString(), manager, developer);
              } catch (Exception e1) {
                e1.printStackTrace();
              } 
            } 
            if (shrl.isSelected() && all.isSelected() && !updater1.inputfiletext.getText().isEmpty()) {
              String manager = "Shirel";
              String developer = "All";
              try {
                updater1.begin(updater1.inputfiletext.getText().toString(), manager, developer);
              } catch (Exception e1) {
                e1.printStackTrace();
              } 
            } 
            if (shrl.isSelected() && all.isSelected() && updater1.inputfiletext.getText().isEmpty()) {
              String manager = "Shirel";
              String str1 = "All";
            } 
          }
        });
    this.frame.getContentPane().setLayout((LayoutManager)null);
    this.frame.getContentPane().add(btnNewButton);
    JSeparator separator_2 = new JSeparator();
    separator_2.setBounds(-11, 304, 853, 2);
    this.frame.getContentPane().add(separator_2);
    JLabel lblNewLabel = new JLabel("New Tickets :");
    lblNewLabel.setFont(new Font("Tahoma", 1, 11));
    lblNewLabel.setHorizontalAlignment(0);
    lblNewLabel.setBounds(10, 349, 93, 14);
    this.frame.getContentPane().add(lblNewLabel);
    ticketscountsfields = new JTextField();
    ticketscountsfields.setBounds(113, 346, 97, 20);
    this.frame.getContentPane().add(ticketscountsfields);
    ticketscountsfields.setColumns(10);
    otherfields = new JTextField();
    otherfields.setBounds(113, 399, 97, 20);
    this.frame.getContentPane().add(otherfields);
    otherfields.setColumns(10);
    JLabel lblNewLabel_1 = new JLabel("Others :");
    lblNewLabel_1.setFont(new Font("Tahoma", 1, 11));
    lblNewLabel_1.setBounds(29, 402, 46, 14);
    this.frame.getContentPane().add(lblNewLabel_1);
    allotedfield = new JTextField();
    allotedfield.setBounds(397, 364, 86, 20);
    this.frame.getContentPane().add(allotedfield);
    allotedfield.setColumns(10);
    JLabel lblNewLabel_2 = new JLabel("Allotted :");
    lblNewLabel_2.setFont(new Font("Tahoma", 1, 11));
    lblNewLabel_2.setHorizontalAlignment(0);
    lblNewLabel_2.setBounds(338, 366, 62, 17);
    this.frame.getContentPane().add(lblNewLabel_2);
    statusfield = new JTextField();
    statusfield.setBounds(632, 327, 190, 20);
    this.frame.getContentPane().add(statusfield);
    statusfield.setColumns(10);
    JLabel lblNewLabel_3 = new JLabel("Conn Status :");
    lblNewLabel_3.setFont(new Font("Tahoma", 1, 11));
    lblNewLabel_3.setHorizontalAlignment(0);
    lblNewLabel_3.setBounds(549, 330, 86, 14);
    this.frame.getContentPane().add(lblNewLabel_3);
    messagefields = new JTextField();
    messagefields.setBounds(632, 386, 190, 20);
    this.frame.getContentPane().add(messagefields);
    messagefields.setColumns(10);
    JLabel lblNewLabel_4 = new JLabel("Message :");
    lblNewLabel_4.setFont(new Font("Tahoma", 1, 11));
    lblNewLabel_4.setBounds(576, 389, 62, 14);
    this.frame.getContentPane().add(lblNewLabel_4);
  }
}
