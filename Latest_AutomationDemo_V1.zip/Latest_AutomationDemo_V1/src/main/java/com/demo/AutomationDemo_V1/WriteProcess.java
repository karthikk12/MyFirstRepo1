package com.demo.AutomationDemo_V1;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.base.CaseFormat;

public class WriteProcess {
	static ArrayList<String> headings = new ArrayList<String>();
	static ArrayList<String> tickets = new ArrayList<String>();
	static ArrayList<String> script = new ArrayList<String>();
	static ArrayList<String> errorcode = new ArrayList<String>();
	static ArrayList<String> fiId = new ArrayList<String>();
	static ArrayList<String> old_status = new ArrayList<String>();
	static ArrayList<String> priority = new ArrayList<String>();
	static ArrayList<String> assignedTo = new ArrayList<String>();
	static ArrayList<String> Comments = new ArrayList<String>();
	static Automation_Status_Analyser analyer = new Automation_Status_Analyser();

	public static void write(String filename, long final_date, List<String> rootcasue, List caseDetails,
			String tempfilename) throws Exception {
		InputStream input = new FileInputStream(filename + ".xlsx");
		int ctr = 1;
		int j = 0;
		Workbook wb = WorkbookFactory.create(input);
		Sheet sheet = wb.getSheetAt(0);

		for (int i = 0; i <= 7; i++) {
			Row row = null;
			Cell cell = null;
			boolean isNull = false;
			ctr = 1;
			while (true) {
				try {
					row = sheet.getRow(ctr++);
					cell = row.getCell(j);
					if (j == 0 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						tickets.add(valider);
					} else if (j == 1 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						script.add(valider);
					} else if (j == 2 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						errorcode.add(valider);
					} else if (j == 3 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						fiId.add(valider);
					} else if (j == 4 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						old_status.add(valider);
					} else if (j == 5 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						priority.add(valider);
					} else if (j == 6 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						assignedTo.add(valider);
					} else if (j == 7 && !StringUtils.isEmpty(cell.toString()) && cell.toString() != null) {
						String valider = validRemoval(cell.toString());
						Comments.add(valider);
					} else if (j == 0 && StringUtils.isEmpty(cell.toString())) {
						tickets.add("-");

					} else if (j == 1 && StringUtils.isEmpty(cell.toString())) {
						script.add("-");

					} else if (j == 2 && StringUtils.isEmpty(cell.toString())) {
						errorcode.add("-");

					} else if (j == 3 && StringUtils.isEmpty(cell.toString())) {
						fiId.add("-");

					} else if (j == 4 && StringUtils.isEmpty(cell.toString())) {
						old_status.add("-");

					} else if (j == 5 && StringUtils.isEmpty(cell.toString())) {
						priority.add("-");

					} else if (j == 6 && StringUtils.isEmpty(cell.toString())) {
						assignedTo.add("-");

					} else if (j == 7 && StringUtils.isEmpty(cell.toString())) {
						Comments.add("-");

					}
				} catch (Exception e) {
					isNull = true;
				}
				if (isNull) {
					j++;
					break;

				}
			}
		}
		calldetails();
		printer(tickets, script, errorcode, fiId, priority, assignedTo, Comments, caseDetails, rootcasue, final_date,
				filename);

	}

	public static void calldetails() {
		System.out.println(tickets.size());
		System.out.println(script.size());
		System.out.println(errorcode.size());
		System.out.println(fiId.size());
		System.out.println(priority.size());
		System.out.println(assignedTo.size());
		System.out.println(Comments.size());
		System.out.println(old_status.size());

		for (String string : old_status) {
			System.out.println("Write  ------" + string);
		}
		System.out.println("-----------------------tickets");
		for (String string : tickets) {
			System.out.println(string);
		}
		System.out.println("-----------------------script");
		for (String string : script) {
			System.out.println(string);
		}
		System.out.println("-----------------------errorcode");
		for (String string : errorcode) {
			System.out.println(string);
		}
		System.out.println("-----------------------fiId");
		for (String string : fiId) {
			System.out.println(string);
		}
		System.out.println("-----------------------priority");
		for (String string : priority) {
			System.out.println(string);
		}
		System.out.println("-----------------------assignedTo");
		for (String string : assignedTo) {
			System.out.println(string);
		}
		System.out.println("-----------------------Comments");

		for (String string : Comments) {
			System.out.println(string);
		}
		System.out.println("-----------------------oveall_status");
		for (String string : analyer.oveall_status) {
			System.out.println(string);
		}

		System.out.println("-----------------------Case Details");
		for (String string : analyer.oveall_status) {
			System.out.println(string);
		}
		System.out.println("-----------------------");

	}

	public static String validRemoval(String input) {
		if (StringUtils.containsIgnoreCase(input.toString(), ".0")) {
			String cutter = StringUtils.substringBefore(input.toString(), ".0");
			return cutter;
		} else {
			return input;
		}

	}

	public static void printer(ArrayList<String> tickets2, ArrayList<String> script2, ArrayList<String> errorcode2,
			ArrayList<String> fiId2, ArrayList<String> priority2, ArrayList<String> assignedTo2,
			ArrayList<String> comments2, List<String> caseDetails, List<String> rootcasue, long final_Date,
			String tempfilename) throws Exception {
		try {
			String filenames = "";
			File folder = new File("C:\\Tickets1");
			if (!folder.exists()) {
				folder.mkdir();
			}
			String unique = StringUtils.substringAfter(tempfilename, "Assignment");
			filenames = "C:\\Tickets\\Closure_Analyser" + unique + ".xlsx";

			String datenow = "";
			String overall = null;

			System.out.println(filenames);
			XSSFWorkbook book = new XSSFWorkbook();
			XSSFSheet sheet = book.createSheet("TICKETS1");
			XSSFCellStyle style = book.createCellStyle();
			style.setBorderBottom(BorderStyle.THIN);
			style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderRight(BorderStyle.THIN);
			style.setRightBorderColor(IndexedColors.BLACK.getIndex());
			style.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			XSSFCellStyle xSSFCellStyle1 = book.createCellStyle();
			XSSFCellStyle xSSFCellStyle7 = book.createCellStyle();
			XSSFCellStyle xSSFCellStyle2 = book.createCellStyle();
			xSSFCellStyle2.setBorderBottom(BorderStyle.THIN);
			xSSFCellStyle2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle2.setBorderRight(BorderStyle.THIN);
			xSSFCellStyle2.setRightBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle2.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			XSSFCellStyle xSSFCellStyle3 = book.createCellStyle();
			xSSFCellStyle3.setBorderBottom(BorderStyle.THIN);
			xSSFCellStyle3.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle3.setBorderRight(BorderStyle.THIN);
			xSSFCellStyle3.setRightBorderColor(IndexedColors.BLACK.getIndex());
			xSSFCellStyle3.setBorderTop(BorderStyle.THIN);
			style.setTopBorderColor(IndexedColors.BLACK.getIndex());
			XSSFFont font = book.createFont();
			style.setAlignment((short) 2);
			XSSFRow row = sheet.createRow(0);
			List<String> headings = Head_call();
			for (int mainitr = 0; mainitr < headings.size(); mainitr++) {
				String cellname = "cell" + mainitr;
				XSSFCell xSSFCell = row.createCell(mainitr);
				xSSFCell.setCellValue(headings.get(mainitr));
				xSSFCellStyle7.setFillPattern((short) 1);
				xSSFCell.setCellStyle((CellStyle) xSSFCellStyle1);
				font.setBoldweight((short) 700);
				xSSFCellStyle7.setFont(font);
				xSSFCell.setCellStyle((CellStyle) style);
				xSSFCellStyle7.setBorderBottom(BorderStyle.THIN);
				xSSFCellStyle7.setBottomBorderColor(IndexedColors.BLACK.getIndex());
				xSSFCellStyle7.setBorderRight(BorderStyle.THIN);
				xSSFCellStyle7.setRightBorderColor(IndexedColors.BLACK.getIndex());
				xSSFCellStyle7.setBorderTop(BorderStyle.THIN);
				style.setTopBorderColor(IndexedColors.BLACK.getIndex());
				xSSFCell.setCellStyle((CellStyle) xSSFCellStyle7);
				xSSFCellStyle7.setAlignment((short) 2);
				xSSFCellStyle7.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
			}

			for (int i = 0; i < tickets.size(); i++) {
				row = sheet.createRow(i + 1);
				for (int j = 0; j < 11; j++) {
					XSSFCell xSSFCell = row.createCell(j);
					if (xSSFCell.getColumnIndex() == 0) {
						xSSFCell.setCellValue(tickets.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 1) {
						xSSFCell.setCellValue(script.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 2) {
						xSSFCell.setCellValue(errorcode.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 3) {
						xSSFCell.setCellValue(fiId.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 4) {
						xSSFCell.setCellValue(analyer.oveall_status.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 5) {
						if (StringUtils.equalsIgnoreCase(analyer.oveall_status.get(i), "Closed")
								|| StringUtils.equalsIgnoreCase(analyer.oveall_status.get(i), "Closed Deployed")
								|| StringUtils.containsIgnoreCase(analyer.oveall_status.get(i), "OFX")
								|| StringUtils.containsIgnoreCase(analyer.oveall_status.get(i), "ON Hold")
								|| StringUtils.containsIgnoreCase(analyer.oveall_status.get(i), "Web Service")
								|| StringUtils.containsIgnoreCase(analyer.oveall_status.get(i), "FDPSPRT")) {

							xSSFCell.setCellValue("Completed");
							xSSFCell.setCellStyle((CellStyle) style);
						} else {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}
//					if (xSSFCell.getColumnIndex() == 6) {
//						if (!StringUtils.equalsIgnoreCase(rootcasue.get(i), "-")
//								&& !StringUtils.isEmpty(rootcasue.get(i))) {
//							xSSFCell.setCellValue(rootcasue.get(i));
//							xSSFCell.setCellStyle((CellStyle) style);
//						} else {
//							xSSFCell.setCellValue(" ");
//							xSSFCell.setCellStyle((CellStyle) style);
//						}
//					}
					if (xSSFCell.getColumnIndex() == 6) {
						if (!StringUtils.isEmpty(rootcasue.get(i))) {
							xSSFCell.setCellValue(rootcasue.get(i));
							xSSFCell.setCellStyle((CellStyle) style);
						}

						else {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						}

					}

					if (xSSFCell.getColumnIndex() == 7) {
						xSSFCell.setCellValue(String.valueOf(priority.get(i)));
						xSSFCell.setCellStyle((CellStyle) style);
					}

					if (xSSFCell.getColumnIndex() == 8) {
						xSSFCell.setCellValue(assignedTo.get(i));
						xSSFCell.setCellStyle((CellStyle) style);
					}
					if (xSSFCell.getColumnIndex() == 10) {
						if (!StringUtils.isEmpty(caseDetails.get(i))) {
							xSSFCell.setCellValue(caseDetails.get(i));
							xSSFCell.setCellStyle((CellStyle) style);
						} else {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}

//					if (xSSFCell.getColumnIndex() == 9) {
//						if (!StringUtils.isEmpty(comments2.get(i))) {
//							xSSFCell.setCellValue(comments2.get(i));
//							xSSFCell.setCellStyle((CellStyle) style);
//
//						} else {
//							xSSFCell.setCellValue(" ");
//							xSSFCell.setCellStyle((CellStyle) style);
//						}
//					}
					if (xSSFCell.getColumnIndex() == 9) {
						if (!StringUtils.isEmpty(comments2.get(i))) {
							xSSFCell.setCellValue(comments2.get(i));
							xSSFCell.setCellStyle((CellStyle) style);
						} else {
							xSSFCell.setCellValue(" ");
							xSSFCell.setCellStyle((CellStyle) style);
						}
					}

				}
			}
			for (int allign = 0; allign < 17; allign++) {
				sheet.autoSizeColumn(allign);
			}
			row = sheet.createRow(tickets.size() + 5);
			XSSFCell xSSFCell1 = row.createCell(0);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellValue("Closed : ");
			xSSFCellStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			xSSFCellStyle1.setFillPattern((short) 1);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			font.setBoldweight((short) 700);
			xSSFCellStyle1.setFont(font);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			XSSFCell xSSFCell2 = row.createCell(1);
			xSSFCell2.setCellValue(analyer.close_cnnt);
			xSSFCell2.setCellStyle((CellStyle) style);
			String value1 = String.valueOf(tickets.size());
			row = sheet.createRow(tickets.size() + 6);
			xSSFCell1 = row.createCell(0);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellValue("Completed : ");
			xSSFCellStyle2.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			xSSFCellStyle2.setFillPattern((short) 1);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle1);
			font.setBoldweight((short) 700);
			xSSFCellStyle2.setFont(font);
			xSSFCell1.setCellStyle((CellStyle) style);
			xSSFCell1.setCellStyle((CellStyle) xSSFCellStyle2);
			xSSFCell2 = row.createCell(1);
			xSSFCell2.setCellValue(analyer.otherCount);
			xSSFCell2.setCellStyle((CellStyle) style);

			System.out.println(filenames);
			FileOutputStream out = new FileOutputStream(new File(filenames));
			book.write(out);

			System.out.println("!!!!!---------------FILE CREATED Successfullly---------------!!!!!");
		} catch (IndexOutOfBoundsException e) {
			calldetails();
		}
	}

	protected static List<String> Head_call() {
		headings.add("TICKET ID");
		headings.add("SCRIPT NAME");
		headings.add("ERROR CODE");
		headings.add("FI ID");
		headings.add("STATUS");
		headings.add("TASK STATUS");
		headings.add("ROOT CAUSE");
		headings.add("PRIORITY");
		headings.add("ASSIGNED TO");
		headings.add("COMMENTS");
		headings.add("CASES");

		return headings;
	}
}