package com.demo.AutomationDemo_V1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.ProgressMonitor;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Desktop;

import javax.swing.JProgressBar;
import java.awt.SystemColor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JPasswordField;
import javax.swing.UIManager;

public class Automation_Status_Analyser {

	static JFrame frame;
	JTextField input_field;
	static ArrayList<String> First_ticketNumber = new ArrayList<String>();
	static ArrayList<String> ticketNumber = new ArrayList<String>();
	static File details_form = new File("C:\\Develop avecto\\encryption.txt");
	static Desktop desk = Desktop.getDesktop();
	static boolean recheck = false;
	static Encrypt_text encrypt = new Encrypt_text();
	static JTextField user_name_field;
	static String username;
	static String password;
	static ArrayList<String> oveall_status = new ArrayList<String>();
	static ArrayList<String> root_cause = new ArrayList<String>();
	static ArrayList<String> caseDetails = new ArrayList<String>();
	static String vault_permission = "false";
	static Encrypt_text encrypt_obj = new Encrypt_text();
	static JTextField Close_field;
	static JTextField err_msg_field;
	static int close_cnnt = 0;
	static JPasswordField password_fileld;
	static WriteProcess process = new WriteProcess();
	static JTextField Time_take;
	static int retry = 0;

	static JTextField Completed_field;
	static int sf_count = 0;
	static int onHold_cnt = 0;

	static int cnt = 0;
	static int otherCount = 0;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Automation_Status_Analyser window = new Automation_Status_Analyser();
					Automation_Status_Analyser.frame.setVisible(true);
					// window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void dashit_login(DesiredCapabilities capabilities, WebDriver driver, String filename,
			String temp_filename) throws Exception {
		if(ticketNumber.size()>4) {
			Time_take.setText("11 Inuted");
			Time_take.setBackground(Color.RED);
		}
		if (retry > 4) {
			err_msg_field.setText("Low Internet Connection");
			err_msg_field.setBackground(Color.RED);
		} else {
			boolean check = false;
			try {

				Thread.sleep(1000);
				driver.get("https://dash.intuit.com/platform/#/");
				driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
				driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);
				driver.findElement(By.xpath("//input[@class='sso-submit']")).click();
				driver.findElement(By.id("duo_iframe"));
				driver.switchTo().frame(0);
				driver.findElement(By.xpath("//button[@type='submit'][contains(.,'Call Me')]")).click();
				Thread.sleep(30000);
				check = true;
				status_finder(capabilities, driver, filename, temp_filename);

			} catch (NoSuchElementException e) {
				retry++;
				dashit_login(capabilities, driver, filename, temp_filename);
			}
		}
	}

	public static Date date_fetcher() throws Exception {
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		String track = format.format(date);
		Date acc_date = format.parse(track);
		System.out.println(acc_date);
		return acc_date;

	}

	public static Date date_fetcher2() throws Exception {
		Date dates = new Date();
		SimpleDateFormat formats = new SimpleDateFormat("HH:mm:ss");
		String track = formats.format(dates);
		Date acc_date = formats.parse(track);
		System.out.println(acc_date);
		return acc_date;

	}

	public static void getcredentails(String[] credentials) {
		String exist_cred[] = new String[2];
		username = credentials[0];
		password = credentials[1];

	}

	public static void begin(String filename) throws Exception {
		System.out.println(filename);
		String temp_file = filename;
		String exist_cred[] = new String[2];
		try {

			if (!username.isEmpty() && !password.isEmpty() && vault_permission.equals("true") && !filename.isEmpty()) {
				encrypt_obj.FileCreator(username, password);
			} else if (username.isEmpty() && password.isEmpty() && vault_permission.equals("false")
					&& !filename.isEmpty()) {
				encrypt_obj.pick_cred(username, password);
				System.out.println(username);
				System.out.println(password);
			}

			else if (StringUtils.isEmpty(username) || StringUtils.isEmpty(password)) {
				err_msg_field.setText("Username & password is empty");
				err_msg_field.setBackground(Color.RED);
				System.out.println("Field Error #2");

			}
			if (!StringUtils.isEmpty(username) && !StringUtils.isEmpty(password)) {
				System.setProperty("webdriver.chrome.driver", "C:\\SW\\chromedriver_win32\\chromedriver.exe");
				DesiredCapabilities capabilities = new DesiredCapabilities();
				WebDriver driver = new ChromeDriver();
				StringBuffer sb1 = new StringBuffer();
				sb1.append(String.valueOf(String.valueOf(filename)) + ".xlsx");
				InputStream input = new FileInputStream(sb1.toString());
				int ctr = 1;
				Workbook wb = WorkbookFactory.create(input);
				Sheet sheet = wb.getSheetAt(0);
				Row row = null;
				Cell cell = null;
				boolean isNull = false;
				while (true) {
					try {
						row = sheet.getRow(ctr++);
						cell = row.getCell(0);
						First_ticketNumber.add(cell.toString());
					} catch (Exception e) {
						isNull = true;
					}
					if (isNull) {
						input.close();
						dashit_login(capabilities, driver, filename, temp_file);
						return;
					}
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			err_msg_field.setText("Username and Password EMPTY");
			err_msg_field.setBackground(Color.RED);

		}
	}

	public Automation_Status_Analyser() {
		try {
			initialize();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	protected void initialize() throws Exception {
		frame = new JFrame("Auto Analyzer >>>>> Calculating......");
		frame.getContentPane().setBackground(new Color(153, 204, 204));
		frame.getContentPane().setFont(new Font("Times New Roman", Font.PLAIN, 15));
		frame.setBounds(100, 100, 818, 461);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		input_field = new JTextField();
		input_field.setBounds(268, 189, 317, 22);
		input_field.setBackground(SystemColor.menu);
		frame.getContentPane().add(input_field);
		input_field.setColumns(10);

		user_name_field = new JTextField();
		user_name_field.setBounds(122, 83, 202, 22);
		user_name_field.setBackground(SystemColor.control);
		user_name_field.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(user_name_field);
		user_name_field.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("USER NAME :");
		lblNewLabel_1.setBounds(31, 86, 97, 16);
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("PASSWORD :");
		lblNewLabel_2.setBounds(483, 86, 97, 16);
		lblNewLabel_2.setForeground(Color.BLUE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("AUTO CLOSURE ANALYSER  #C2");
		lblNewLabel_3.setBounds(243, 13, 349, 35);
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel_3);

		JSeparator separator = new JSeparator();
		separator.setBounds(-13, 243, 869, 2);
		separator.setForeground(SystemColor.activeCaption);
		frame.getContentPane().add(separator);

		JLabel lblNewLabel_4 = new JLabel("Total Closure :");
		lblNewLabel_4.setBounds(12, 284, 126, 25);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel_4);

		Close_field = new JTextField();
		Close_field.setBounds(122, 285, 114, 22);
		Close_field.setFont(new Font("Tahoma", Font.BOLD, 13));
		Close_field.setHorizontalAlignment(SwingConstants.CENTER);
		Close_field.setBackground(SystemColor.control);
		frame.getContentPane().add(Close_field);
		Close_field.setColumns(10);

		JLabel lblNewLabel_5 = new JLabel("Status >> : ");
		lblNewLabel_5.setBounds(384, 286, 104, 21);
		lblNewLabel_5.setForeground(new Color(255, 0, 0));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblNewLabel_5);

		err_msg_field = new JTextField();
		err_msg_field.setBounds(483, 285, 292, 22);
		err_msg_field.setBackground(new Color(255, 0, 0));
		err_msg_field.setFont(new Font("Tahoma", Font.BOLD, 13));
		err_msg_field.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(err_msg_field);
		err_msg_field.setColumns(10);

		password_fileld = new JPasswordField();
		password_fileld.setBounds(580, 83, 202, 22);
		password_fileld.setBackground(SystemColor.control);
		password_fileld.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(password_fileld);
		password_fileld.setEchoChar('*');

		final JCheckBox vault_check = new JCheckBox("Secure Vault");
		vault_check.setBounds(361, 136, 114, 25);
		vault_check.setBackground(SystemColor.inactiveCaption);
		frame.getContentPane().add(vault_check);

		JLabel lblNewLabel = new JLabel("File+Path :");
		lblNewLabel.setBounds(190, 192, 104, 16);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		frame.getContentPane().add(lblNewLabel);

		err_msg_field.setText("Processing.......");
		err_msg_field.setBackground(Color.ORANGE);
		JButton btnNewButton = new JButton("Analyse >");
		btnNewButton.setBounds(594, 189, 97, 25);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setForeground(new Color(75, 0, 130));
		btnNewButton.setBackground(SystemColor.controlHighlight);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				err_msg_field.setText("Processing.......");
				err_msg_field.setBackground(Color.ORANGE);
				if (!input_field.getText().isEmpty()) {

					String filename = input_field.getText();
					username = user_name_field.getText();
					password = password_fileld.getText();
					if (!StringUtils.isEmpty(filename) && !StringUtils.isEmpty(username)
							&& !StringUtils.isEmpty(password) && vault_check.isSelected()) {
						vault_permission = "true";

						try {
							err_msg_field.setText("Processing.......");
							err_msg_field.setBackground(Color.ORANGE);
							begin(filename.trim());
						} catch (Exception e) {

							e.printStackTrace();
						}
					}
					if (!StringUtils.isEmpty(filename) && !StringUtils.isEmpty(username)
							&& !StringUtils.isEmpty(password) && !vault_check.isSelected()) {

						vault_permission = "false";
						try {
							err_msg_field.setText("Processing.......");
							err_msg_field.setBackground(Color.ORANGE);
							begin(filename.trim());
						} catch (Exception e) {

							e.printStackTrace();
						}
					}
					if (!StringUtils.isEmpty(filename) && StringUtils.isEmpty(username) && StringUtils.isEmpty(password)
							&& !vault_check.isSelected()) {

						vault_permission = "false";
						try {
							err_msg_field.setText("Processing.......");
							err_msg_field.setBackground(Color.ORANGE);
							begin(filename.trim());
						} catch (Exception e) {

							e.printStackTrace();
						}
					}

					else {
						System.out.println("Field Empty error");
					}
				}
			}
		});
		frame.getContentPane().add(btnNewButton);

		Time_take = new JTextField();
		Time_take.setBounds(483, 345, 292, 22);
		Time_take.setFont(new Font("Tahoma", Font.BOLD, 13));
		Time_take.setHorizontalAlignment(SwingConstants.CENTER);
		Time_take.setBackground(SystemColor.menu);
		frame.getContentPane().add(Time_take);
		Time_take.setColumns(10);

		JLabel lblNewLabel_6 = new JLabel("Time Taken :");
		lblNewLabel_6.setBounds(384, 348, 91, 16);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel_6);

		Completed_field = new JTextField();
		Completed_field.setBounds(122, 345, 116, 22);
		Completed_field.setBackground(SystemColor.inactiveCaptionBorder);
		Completed_field.setFont(new Font("Tahoma", Font.BOLD, 13));
		Completed_field.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(Completed_field);
		Completed_field.setColumns(10);

		JLabel complete_field = new JLabel("Completed :");
		complete_field.setBounds(31, 348, 87, 16);
		complete_field.setFont(new Font("Tahoma", Font.BOLD, 13));
		frame.getContentPane().add(complete_field);

	}

	public static void status_finder(DesiredCapabilities capabilities, WebDriver driver, String filename,
			String tempfilename) throws Exception {

		Date startdate = date_fetcher();
		System.out.println("Start date" + startdate);
		String perfect_str = null;
		for (String string : First_ticketNumber) {
			if (StringUtils.isNotEmpty(string) && string != null) {
				String validstring = string.trim();
				if (validstring.contains(".0")) {
					perfect_str = StringUtils.substringBefore(validstring, ".0");
					ticketNumber.add(perfect_str);
				} else {
					ticketNumber.add(validstring);
				}

			}
		}
		int totalTck = ticketNumber.size();
		for (String string : ticketNumber) {
			System.out.println(string);
		}
		for (int i = 0; i < ticketNumber.size(); i++) {
			retry = 0;
			String status = "";
			boolean check = false;
			String cutter_status = null;
			String create_status = null;
			boolean nextstatus = false;
			while (!nextstatus) {
				retry++;
				try {

					driver.get("https://dash.intuit.com/platform/#/widget/FDPTools/FdpSupportWebToolWidget@0.0.10");
					Thread.sleep(5000);
					driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]"))
							.sendKeys(ticketNumber.get(i));
					driver.findElement(By.xpath("//span[contains(@class,'glyphicon glyphicon-search')]")).click();
					Thread.sleep(10000);

					try {
// Error Code , Case History Details
						if (check == false) {
							status = driver.findElement(By.xpath(
									"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[4]/dl[1]/dd[1]/div[1]"))
									.getText();
							if ((status != null && !status.isEmpty() && StringUtils.equalsIgnoreCase(status, "0"))
									|| (status != null && !status.isEmpty()
											&& StringUtils.equalsIgnoreCase(status, "103"))) {
								Thread.sleep(5000);

								driver.findElement(By.xpath("//strong[contains(.,'Cases')]")).click();
								Thread.sleep(3000);
								String casehistory = driver.findElement(By.xpath("(//td[contains(@tabindex,'2')])[1]"))
										.getText();
								System.out.println(ticketNumber.get(i) + "---------->" + casehistory.trim());
								caseDetails.add(casehistory);
							}
							if (status == null || status.isEmpty()) {
								check = false;
								nextstatus = false;
							}

						}
					} catch (NoSuchElementException e) {
						System.out.println("Case History exception");
					} catch (NullPointerException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
						}
					}

					try {
// JIRA Section
						if (check == false) {
							status = driver.findElement(By.xpath("(//a[contains(@target,'_blank')])[1]")).getText();

							if (status != null && !status.isEmpty()) {
								check = true;
								nextstatus = true;
								cnt++;
								System.out.println(ticketNumber.get(i) + "---------->" + status.trim());
								oveall_status.add(status.trim().toString());
								caseDetails.add("-");
								root_cause.add("Jira Dependency");
								otherCount++;
							}
							if (status == null || status.isEmpty()) {
								check = false;
								nextstatus = false;
							}

						}
					} catch (NoSuchElementException e) {
						System.out.println("Jira sectrion exception");
					} catch (NullPointerException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
						}
					}
					try {
// OFX section
						if (check == false) {
							status = driver.findElement(By.xpath("(//div[contains(.,'OFX')])[15]")).getText();

							if (status != null && !status.isEmpty()) {
								check = true;
								nextstatus = true;
								cnt++;
								System.out.println(ticketNumber.get(i) + "---------->" + status.trim());
								oveall_status.add(status.trim().toString());
								root_cause.add("OFX");
								caseDetails.add("-");
								otherCount++;
							}
							if (status == null || status.isEmpty()) {
								check = false;
								nextstatus = false;
							}

						}
					} catch (NoSuchElementException e) {

					} catch (NullPointerException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
						}
					}

					try {
// Web Service
						if (check == false) {
							status = driver.findElement(By.xpath("(//div[contains(.,'Web Service')])[15]")).getText();

							if (status != null && !status.isEmpty()) {
								check = true;
								nextstatus = true;
								cnt++;
								System.out.println(ticketNumber.get(i) + "---------->" + status.trim());
								oveall_status.add(status.trim().toString());
								root_cause.add("Web Service");
								caseDetails.add("-");
								otherCount++;
							}
							if (status == null || status.isEmpty()) {
								check = false;
								nextstatus = false;
							}

						}
					} catch (NoSuchElementException e) {

					} catch (NullPointerException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
						}
					}

					try {
//TC, IP, ON Hold  Section					
						if (check == false) {
							driver.findElement(By.xpath("(//div[contains(@class,'form-group')])[1]"));
							status = driver.findElement(By.xpath("(//div[contains(@class,'form-group')])[1]"))
									.getText();
							cutter_status = StringUtils.substringBetween(status, "Status", ")");
							create_status = StringUtils.substringBefore(cutter_status, "(");
							if (!cutter_status.isEmpty() && cutter_status != null) {
								check = true;
							}
							nextstatus = true;
							cnt++;
							if (StringUtils.containsIgnoreCase(create_status, "On Hold")) {
								onHold_cnt++;
								otherCount++;
							}
							System.out.println(ticketNumber.get(i) + "---------->" + create_status.trim());
							oveall_status.add(create_status.trim().toString());
							root_cause.add("-");
							caseDetails.add("-");
						}
					} catch (NoSuchElementException e) {

					} catch (NullPointerException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
						}
					}
// Closed,Closed Deployed Section				
					try {
						if (check == false) {
							status = driver.findElement(By.xpath("(//div[contains(.,'Closed')])[14]")).getText();
							if (StringUtils.equalsIgnoreCase(status, "Closed")) {
								status = "Closed";
							} else if (StringUtils.equalsIgnoreCase(status, "Closed Deployed")) {
								status = "Closed Deployed";
							} else if (StringUtils.equalsIgnoreCase(status, "Ready to be Deployed")) {
								status = "Ready to be Deployed";
							}

							if (StringUtils.equalsIgnoreCase(status, "Closed")
									|| StringUtils.equalsIgnoreCase(status, "Ready To Be Deployed")
									|| StringUtils.equalsIgnoreCase(status, "Closed Deployed")) {
								driver.findElement(By.xpath("//strong[contains(.,'Ticket Details')]")).click();
								Thread.sleep(5000);
								String rootcause = driver.findElement(By.xpath(
										"/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[4]/div[2]/div[1]/div[1]/div[6]/div[1]/div[2]/ul[1]/li[1]"))
										.getText();
								if (StringUtils.containsIgnoreCase(rootcause, "DB Update")
										|| StringUtils.containsIgnoreCase(rootcause, "Im Change")
										|| StringUtils.containsIgnoreCase(rootcause, "Recent fix")) {
									nextstatus = true;
									cnt++;
									close_cnnt++;
									otherCount++;
									System.out.println(
											ticketNumber.get(i) + "---------->" + status + "------>" + rootcause);
									root_cause.add(rootcause.trim().toString());
									oveall_status.add(status.trim().toString());
									caseDetails.add("-");

								} else {
									nextstatus = true;
									cnt++;
									close_cnnt++;
									otherCount++;
									System.out.println(
											ticketNumber.get(i) + "---------->" + status + "------>" + rootcause);
									root_cause.add(rootcause.trim().toString());
									oveall_status.add(status.trim().toString());
									caseDetails.add("-");
								}
							}
							if (StringUtils.containsIgnoreCase(status, "Closed Deployed")
									|| StringUtils.containsIgnoreCase(status, "Ready to be Deployed")) {
								nextstatus = true;
								cnt++;
								close_cnnt++;
								otherCount++;
								System.out.println(ticketNumber.get(i) + "---------->" + status);
								oveall_status.add(status.trim().toString());
								caseDetails.add("-");
							}
						}
					} catch (NoSuchElementException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
							System.out.println("Successfully cleared cache.................");
						}
						System.out.println("Starting...................");
					} catch (NullPointerException e) {
						if (retry > 3) {
							driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
						}
					}

				}

				catch (Exception e) {
					if (retry > 3) {
						driver.findElement(By.xpath("//input[contains(@name,'ticketSearchId')]")).clear();
					}
					retry++;
					e.printStackTrace();
					System.out.println("Something went wrong");
				}
			}

		}
		System.out.println(close_cnnt);
		Close_field.setText(String.valueOf(close_cnnt));
		if (close_cnnt > 20) {
			Automation_Status_Analyser.Close_field.setText(String.valueOf(close_cnnt));
			Close_field.setBackground(Color.GREEN);
		} else if (close_cnnt > 10 && close_cnnt <= 20) {
			Automation_Status_Analyser.Close_field.setText(String.valueOf(close_cnnt));
			Close_field.setBackground(Color.YELLOW);
		} else if (close_cnnt <= 10) {
			Automation_Status_Analyser.Close_field.setText(String.valueOf(close_cnnt));
			Close_field.setBackground(Color.RED);
		}
		System.out.println();
		Close_field.setText(String.valueOf(close_cnnt));

		int completed_count = close_cnnt + otherCount;
		Completed_field.setText(String.valueOf(completed_count));
		Completed_field.setBackground(Color.GREEN);
		Date end_date = date_fetcher2();
		System.out.println("End date" + end_date);

		Close_field.setText(String.valueOf(close_cnnt));
		err_msg_field.setText("Completed");
		err_msg_field.setBackground(Color.GREEN);
		int final_date = (int) (end_date.getTime() - startdate.getTime());
		int acc_calc_date = final_date / (60 * 1000) % 60;
		Time_take.setText(String.valueOf(acc_calc_date) + " minutes");
		Time_take.setBackground(Color.GREEN);
		process.write(filename, final_date, root_cause, caseDetails, tempfilename);
	}

}
