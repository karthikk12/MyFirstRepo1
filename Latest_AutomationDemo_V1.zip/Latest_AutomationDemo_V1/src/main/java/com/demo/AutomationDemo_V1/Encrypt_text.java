package com.demo.AutomationDemo_V1;

import java.awt.Color;
import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JFrame;

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import com.gargoylesoftware.htmlunit.javascript.host.security.Credential;

public class Encrypt_text extends JFrame {
	static Automation_Status_Analyser analyzer = new Automation_Status_Analyser();
	static StringBuffer buffer = new StringBuffer();
	static File folder = new File("C:\\Vault");
	static File filename = new File("C:\\Vault\\ectfile.txt");
	static String credentials[] = new String[2];
	static Desktop desk = Desktop.getDesktop();
	static String decrypt_cred[] = new String[2];

	public static void FileCreator(String username, String password) throws Exception {
		if (!folder.exists()) {
			folder.mkdir();
			if (!filename.exists()) {
				filename.createNewFile();
				writeprocess(username, password);
			}
		} else {
			pick_cred(username, password);
		}
	}

	public static void writeprocess(String username, String password) throws Exception {
		encrypted_text(password, username);
	}

	public static void pick_cred(String username, String password) throws Exception {
		analyzer.err_msg_field.setText("Processing.......");
		analyzer.err_msg_field.setBackground(Color.ORANGE);
		DecryptedText(username, password);

	}

	public static void encrypted_text(String password, String username) throws Exception {
		int passlength = password.length();
		for (int i = 0; i < passlength; i++) {
			if (Character.isAlphabetic(password.charAt(i))) {
				char c = password.charAt(i);
				buffer.append(String.valueOf(++c));
			} else {
				buffer.append(password.charAt(i));
			}
		}
		String enc_password = buffer.toString();
		writer(username, enc_password);
	}

	public static void writer(String username, String password) throws Exception {

		PrintWriter writer = new PrintWriter(filename);
		writer.print(username);
		writer.write(System.lineSeparator());
		writer.print(password);
		writer.close();
//		System.out.println("Encrypted Text :" + buffer.toString());
		DecryptedText(username, password);

	}

	public static void DecryptedText(String username, String password) throws Exception {
		try {
			fetching_Up_Data(username, password);
			String decryp_pass = credentials[1].toString();
			buffer.delete(0, buffer.length());
			for (int i = 0; i < decryp_pass.length(); i++) {
				char c = decryp_pass.charAt(i);
				if (Character.isAlphabetic(c)) {
					buffer.append(--c);
				} else {
					buffer.append(c);
				}
			}
			System.out.println("Decrypteed text :" + buffer.toString());
			for (int i = 0; i < decrypt_cred.length; i++) {
				decrypt_cred[i] = credentials[i];
				if (i == 1) {
					decrypt_cred[i] = buffer.toString();
				}
			}
		} catch (NullPointerException e) {
			analyzer.err_msg_field.setText("Username and Password EMPTY");
			analyzer.err_msg_field.setBackground(Color.RED);
		}

		analyzer.getcredentails(decrypt_cred);

	}

	public static void fetching_Up_Data(String username, String password) throws Exception {
		try {

			int i = 0;
			Scanner reader = new Scanner(filename);
			while (reader.hasNext()) {
				String eachline = reader.nextLine();
				credentials[i] = eachline;
				i++;
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("E");
			analyzer.err_msg_field.setText("File is already Open State...");
			analyzer.err_msg_field.setBackground(Color.RED);
		}
	}

}
